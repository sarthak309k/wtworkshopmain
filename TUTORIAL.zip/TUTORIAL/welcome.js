welcome=(name)=>
{

    console.log("Welcome %s ",name)
}

seeYa=(name)=>{
    console.log("See Yaaa :- %s:(",name);
}

module.exports={welcome,seeYa}