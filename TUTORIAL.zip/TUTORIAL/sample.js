console.log("Sample Text");
var a=10;
var b=4.5;
console.log(a+b);
if(b >a)
{
 console.log("Number %d greater",b )
}
else{
console.log("Number %d is greater",a)
}

const num=30;
console.log(num);
console.log("Number =",num);

