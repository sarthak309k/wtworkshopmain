const os=require('os')
const usr=os.userInfo()
console.log(usr)
console.log(os.freemem())