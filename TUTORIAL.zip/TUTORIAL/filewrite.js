var fs=require('fs')

/*
var data=fs.readFileSync('./fsopr/result.txt');
console.log(data.toString())
*/

var data=fs.readFileSync('./fsopr/result.txt',function(err,data)
{
    if(err) return console.log(err);
    return console.log(data.toString());
});
console.log(data.toString());
console.log('Reading Completed');


console.log('Activity Started')
setTimeout(()=>{
    console.log("Do Something")
},2000)
console.log('Activity Completed');