const { error } = require("console")

const multiplication=(numberone,numbertwo)=>{
    return new Promise((resolve,reject)=>{
      setTimeout(() => {
        if(numberone<0 || numbertwo<0){
            reject("Only Positive numbers allowed")
        }
         resolve(numberone*numbertwo)
      },2000)
    }) 
}

multiplication(-10, 2).then((e)=>console.log(e)).catch((error)=>console.log(error))

const addElement=(arr,arr1)=>{
    return new Promise((resolve,reject)=>{
    setTimeout(()=>{
        if(arr.length<5)
        {reject("Array Should Contain More Than 5 elements")}           
        resolve(arr1.push(arr1.push(arr)))
    })

    })}

var arr=['A','B','C','D'];
var arr1=[];
addElement(arr,arr1).then((e)=>console.log(e)).catch((error)=>console.log(error))

console.log(arr1);



