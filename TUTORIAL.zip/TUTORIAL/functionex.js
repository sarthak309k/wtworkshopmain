var str="Hello Noobb";
console.log(str);

function printMsg()
{
    var str="Hello Piroo";
    console.log("Inside Something",str);
} 

printMsg()

var name="Sarthak";

const greet=()=>{
    console.log('Greetings');
}

const greetMe=(name)=>{
    console.log("Hellowww Greeting to %s ",name)
}

greetMe(name);

const greetMeDef=(name="Vaishnavi")=>{
console.log("Helloww Greetings %s ",name);
}

greetMeDef();

const a=10,b=20;
const opr=(a,b,op)=>{
    if(op=='Add')
     {
        console.log(a+b);
     }
     else if(op=='Sub')
     {
        console.log(a-b);
     }
}

const heyy=require('./welcome.js')

heyy.welcome('Sarthak');
heyy.seeYa('Sarthak')