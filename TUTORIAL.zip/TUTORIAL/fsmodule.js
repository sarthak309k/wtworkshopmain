const {readFileSync,writeFileSync,read}=require('fs')
const first=readFileSync('./fsopr/first.txt','utf-8');
const second=readFileSync('./fsopr/second.txt','utf-8');

console.log(first)
console.log(second)

writeFileSync('./fsopr/result.txt',first +' \n'+ second);
