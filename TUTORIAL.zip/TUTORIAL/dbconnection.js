var mysql=require('mysql')

var dbconn=mysql.createConnection({
 host:'localhost',
 port:3306,
 user:'root',
 password:'Sarthak1',
 database:'mydb'
});

dbconn.connect(function(err){
    if(err){
        console.log('Database Connection failed');
        console.log(err);
    }
    else{
        console.log('Connection Successful');
    }
});

var rec={name:'Sarthak Kashikar',mail:'sarthak@gmail.com',pass:'pass123'};

dbconn.query('INSERT INTO user_details SET ?', rec, function(err,res){
    if(err) throw err;
    else
    console.log('record inserted successfully')
    
  });

  //Select all customers and return the result object:
  dbconn.query("SELECT * FROM user_details", function (err, result, fields) {
    if (err) throw err;
    console.log(result);
    //console.log('field length:',fie)
    result.forEach( (row) => {
        console.log(`${row.name} : ${row.mail}`);
      });
     
  });
