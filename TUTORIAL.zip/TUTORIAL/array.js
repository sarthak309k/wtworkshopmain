var arr=['JS','NODE JS','REACT JS','ANGULAR JS','TypeScript'];
console.log(arr[0]);
console.log(arr[3]);

arr.forEach((item)=>{
console.log(item);
})

var arr1=arr.map((langName)=>langName.toUpperCase())
console.log(arr);

arr1.push('Express Js');
console.log(arr1)

var arr2=arr1.filter((element)=>element.length<4)
console.log(arr2);

var arr3=arr1.filter((element)=>element.startsWith('T'));
console.log(arr3)

var arr4=arr1.reverse();
console.log(arr4);

const pro=['Sarthak','kashikar','sarthak@gmail.com'];
const [firstname,lastname,email]=pro;

console.log(firstname);
console.log(lastname);
console.log(email);

console.log('\n')

const pro1=['Sarthak','Kashikar','sarthak@gmail.com'];
const [firstname1,...details]=pro;
console.log(firstname1);
console.log(details);