module.exports = {
    HOST: "localhost",
    port:3306,
    USER: "root",
    PASSWORD: "Sarthak1",
    DB: "mydb"
  };